//
//  CustomTableViewCell.h
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel *firstLabel;
@property (nonatomic,strong)UILabel *secondLabel;
@property (nonatomic,strong)UILabel *thirdLabel;
@end
