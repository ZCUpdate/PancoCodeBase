//
//  CustomTableViewCell.m
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "CustomTableViewCell.h"
#import "Masonry.h"

@implementation CustomTableViewCell
-(UILabel *)firstLabel
{
    if (!_firstLabel) {
        _firstLabel = [[UILabel alloc]init];
        [self addSubview:_firstLabel];
        [_firstLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            //
            make.left.mas_equalTo(50);
            make.top.mas_equalTo(13);
        }];
    }
    return _firstLabel;
}
-(UILabel *)secondLabel
{
    if (!_secondLabel) {
        _secondLabel = [[UILabel alloc]init];
        [self addSubview:_secondLabel];
        [_secondLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            //
            make.left.mas_equalTo(189);
            make.top.mas_equalTo(13);
        }];
    }
    return _secondLabel;
}
-(UILabel *)thirdLabel
{
    if (!_thirdLabel) {
        _thirdLabel = [[UILabel alloc]init];
        [self addSubview:_thirdLabel];
        [_thirdLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            //
            make.left.mas_equalTo(318);
            make.top.mas_equalTo(13);
        }];
    }
    return _thirdLabel;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
