//
//  MainViewController.m
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "MainViewController.h"
#import "FirstTableView.h"
#import "SecondTableView.h"
@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor yellowColor];
    NSArray *arr = @[@"来自分销商",@"来自代理商"];
    UISegmentedControl *segc = [[UISegmentedControl alloc]initWithItems:arr];
    
    segc.frame = CGRectMake(0, 20, self.view.frame.size.width, 30);
    segc.selectedSegmentIndex = 0 ;
    [segc addTarget:self action:@selector(segeClick:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:segc];
    [self.view addSubview:self.secondTable];
    [self.view addSubview:self.firstTable];
}
- (void)segeClick:(UISegmentedControl *)segc
{
    switch (segc.selectedSegmentIndex) {
        case 0:
            [self.view bringSubviewToFront:self.firstTable];
            break;
            case 1:
            [self.view bringSubviewToFront:self.secondTable];
            break;
        default:
            break;
    }
}
-(UITableView *)firstTable
{
    if (!_firstTable) {
        _firstTable = [[FirstTableView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, 168)];
        [self.firstTable reloadData];
    }
    return _firstTable;
}
-(UITableView *)secondTable
{
    if (!_secondTable) {
        _secondTable = [[SecondTableView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, 168)];
        [self.secondTable reloadData];
        
    }
    return _secondTable;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
