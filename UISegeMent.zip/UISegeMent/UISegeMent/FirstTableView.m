//
//  FirstTableView.m
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "FirstTableView.h"
#import "CustomTableViewCell.h"
@interface FirstTableView()<UITableViewDelegate,UITableViewDataSource>
@end
@implementation FirstTableView
-(NSArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSArray arrayWithObjects:@"1",@"2",@"3",nil] ;
    }
    return _dataArray;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.dataSource = self;
        self.delegate = self;
    }
    return self;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 42;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cll"];
    if (!cell) {
        cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    if (indexPath.row == 0) {
        cell.firstLabel.text = @"来源";
        cell.secondLabel.text = @"嗖嗖币数量";
        cell.thirdLabel.text = @"明细";
    }else if (indexPath.row == 1)
    {
        cell.firstLabel.text = @"一级代理商";
        cell.secondLabel.text = self.dataArray[indexPath.row-1];
        cell.thirdLabel.text = @"查看";
    }else if (indexPath.row == 2)
    {
        cell.firstLabel.text = @"二级代理商";
        cell.secondLabel.text = self.dataArray[indexPath.row - 1];
        cell.secondLabel.text = @"查看";
    }else
    {
        cell.firstLabel.text = @"三级代理商";
        cell.secondLabel.text = self.dataArray[indexPath.row - 1];
        cell.thirdLabel.text = @"查看";
    }
    return cell;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
