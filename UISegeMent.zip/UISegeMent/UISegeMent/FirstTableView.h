//
//  FirstTableView.h
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstTableView : UITableView
@property (nonatomic,strong)NSArray *dataArray;
@end
