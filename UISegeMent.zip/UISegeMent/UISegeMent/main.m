//
//  main.m
//  UISegeMent
//
//  Created by 李增超 on 16/7/6.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
