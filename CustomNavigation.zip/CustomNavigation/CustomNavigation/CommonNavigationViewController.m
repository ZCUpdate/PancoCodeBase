//
//  CommonNavigationViewController.m
//  CustomNavigation
//
//  Created by 李增超 on 16/5/11.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "CommonNavigationViewController.h"

@interface CommonNavigationViewController ()

@end

@implementation CommonNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationBar.barTintColor = [UIColor grayColor];
    self.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithRed:254/255.0 green:208/255.0 blue:55/255.0 alpha:1],NSForegroundColorAttributeName, [UIFont systemFontOfSize:20], NSFontAttributeName, nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
