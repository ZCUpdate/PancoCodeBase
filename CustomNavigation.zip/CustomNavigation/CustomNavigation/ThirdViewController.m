//
//  ThirdViewController.m
//  CustomNavigation
//
//  Created by 李增超 on 16/5/11.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "ThirdViewController.h"
#import "FouthViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blueColor];
    [self.navigationController.navigationBar setHidden:YES];
    
    UIButton *btn = [[UIButton alloc]init];
    btn.frame = CGRectMake(30, 100, 60, 40);
    btn.backgroundColor = [UIColor whiteColor];
    btn.titleLabel.text = @"返回";
    [btn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UIButton *btn2 = [[UIButton alloc]initWithFrame:CGRectMake(30, 160, 60, 40)];
    btn2.titleLabel.text = @"跳";
    [btn2 setTintColor:[UIColor whiteColor]];
    [btn2 setBackgroundColor:[UIColor blackColor]];
    [btn2 addTarget:self action:@selector(jump) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    
}

- (void)back
{
//    [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)jump
{
    [self.navigationController pushViewController:[[FouthViewController alloc]init] animated:YES];
    //在未使用nvgationController时,push方法不管用
//    [self presentViewController:[[FouthViewController alloc]init] animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
//    self.tabBarController.tabBar.hidden = YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
