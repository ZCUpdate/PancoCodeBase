//
//  TabBarViewController.m
//  CustomNavigation
//
//  Created by 李增超 on 16/5/11.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "TabBarViewController.h"
#import "ViewController.h"
#import "CommonNavigationViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"

@interface TabBarViewController ()<UITabBarDelegate,UITabBarControllerDelegate>

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    ViewController *VC = [[ViewController alloc]init];
    SecondViewController *SVC = [[SecondViewController alloc]init];
    NSArray *arr = [NSArray arrayWithObjects:VC,SVC, nil];
    NSArray *title = [NSArray arrayWithObjects:@"first",@"second", nil];
    for (int i = 0; i<2; i++) {
         CommonNavigationViewController *CNVC = [[CommonNavigationViewController alloc]initWithRootViewController:[arr objectAtIndex:i]];
        CNVC.tabBarItem.title = [title objectAtIndex:i];
        [self addChildViewController:CNVC];
    }
    self.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    
    if ([viewController.tabBarItem.title isEqualToString:@"second"]) {
        //
//        [self presentViewController:[[ThirdViewController alloc]init] animated:YES completion:nil];
        [self.navigationController pushViewController:[[ThirdViewController alloc]init] animated:YES];
        return NO;
    }
    return YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
