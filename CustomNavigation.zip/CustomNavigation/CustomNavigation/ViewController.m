//
//  ViewController.m
//  CustomNavigation
//
//  Created by 李增超 on 16/5/11.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "ViewController.h"
#import "CommonNavigationViewController.h"
#import "ThirdViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    self.navigationItem.title = @"yellow";
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"点击" forState:UIControlStateNormal];
    btn.frame = CGRectMake(130, 130, 60, 30);
    [btn setBackgroundColor:[UIColor blackColor]];
    [btn addTarget:self action:@selector(touch) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)touch
{
//    self.tabBarController.tabBar.hidden = YES;
//    [self.navigationController pushViewController:[[ThirdViewController alloc]init] animated:YES];
    [self.tabBarController.navigationController pushViewController:[[ThirdViewController alloc]init] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
