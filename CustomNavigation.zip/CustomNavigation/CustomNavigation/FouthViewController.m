//
//  FouthViewController.m
//  CustomNavigation
//
//  Created by 李增超 on 16/5/11.
//  Copyright © 2016年 李增超. All rights reserved.
//

#import "FouthViewController.h"
#import "CommonNavigationViewController.h"

@interface FouthViewController ()

@end

@implementation FouthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    CommonNavigationViewController *cVC = [[CommonNavigationViewController alloc]init];
    [self addChildViewController:cVC];
    self.navigationItem.title = @"测试";
    self.navigationController.navigationBarHidden =  NO;
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton *btn = [[UIButton alloc]init];
    btn.frame = CGRectMake(30, 100, 60, 40);
    btn.backgroundColor = [UIColor grayColor];
//    btn.titleLabel.text = @"返回";
    [btn setTitle:@"返回" forState:UIControlStateNormal];
    btn.tintColor = [UIColor blackColor];
    [btn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)back
{
//    [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
